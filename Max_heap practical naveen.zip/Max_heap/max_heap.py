import time


class MaxHeap:

    def __init__(self):
        self.heap = []

    # Insert an element into Max Heap
    def insert(self, value):
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)

    # Move element upward
    def _heapify_up(self, index):
        while index > 0:
            parent = (index - 1) // 2

            if self.heap[index] > self.heap[parent]:
                self.heap[index], self.heap[parent] = \
                    self.heap[parent], self.heap[index]
                index = parent
            else:
                break

    # Display heap
    def display(self):
        print("Max Heap:", self.heap)


# Main program
print("===== MAX HEAP =====")

n = int(input("Enter number of elements: "))

heap = MaxHeap()

print("Enter", n, "elements:")

start_time = time.perf_counter()

for i in range(n):
    value = int(input(f"Enter element {i + 1}: "))
    heap.insert(value)

end_time = time.perf_counter()

heap.display()

execution_time = end_time - start_time

print("\nExecution Time: {:.8f} seconds".format(execution_time))

print("\nTime Complexity:")
print("Insertion: O(log n)")
print("Building Heap using insertion: O(n log n)")
print("Space Complexity: O(n)")