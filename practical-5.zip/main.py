import time

# Function for 0/1 Knapsack using Dynamic Programming
def knapsack(weights, values, capacity):
    n = len(values)

    # Create DP table
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]

    # Fill the DP table
    for i in range(1, n + 1):
        for w in range(1, capacity + 1):

            if weights[i - 1] <= w:
                dp[i][w] = max(
                    values[i - 1] + dp[i - 1][w - weights[i - 1]],
                    dp[i - 1][w]
                )
            else:
                dp[i][w] = dp[i - 1][w]

    return dp[n][capacity]


# Input
n = int(input("Enter number of items: "))

weights = []
values = []

for i in range(n):
    weight = int(input(f"Enter weight of item {i + 1}: "))
    value = int(input(f"Enter value of item {i + 1}: "))

    weights.append(weight)
    values.append(value)

capacity = int(input("Enter knapsack capacity: "))


# Start execution time
start_time = time.perf_counter()

# Find maximum profit
max_profit = knapsack(weights, values, capacity)

# End execution time
end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time


# Output
print("\nMaximum Profit =", max_profit)
print("Execution Time =", execution_time, "seconds")

print("\nTime Complexity:")
print("Best Case    : O(n * W)")
print("Average Case : O(n * W)")
print("Worst Case   : O(n * W)")

print("\nSpace Complexity: O(n * W)")