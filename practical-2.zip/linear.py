import time

# User input
arr = list(map(int, input("Enter elements (space-separated): ").split()))
target = int(input("Enter the element to search: "))

# Start execution timer
start_time = time.perf_counter()

# Linear Search
found = -1

for i in range(len(arr)):
    if arr[i] == target:
        found = i
        break

# End execution timer
end_time = time.perf_counter()

# Display result
if found != -1:
    print("Element found at index:", found)
else:
    print("Element not found.")

# Execution time
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.9f} seconds")

# Complexity
print("Time Complexity: O(n)")
print("Space Complexity: O(1)")