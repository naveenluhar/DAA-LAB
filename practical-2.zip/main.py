import time

# User input
arr = list(map(int, input("Enter sorted elements (space-separated): ").split()))
target = int(input("Enter the element to search: "))

# Binary Search function
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1

    while low <= high:
        mid = (low + high) // 2

        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1

    return -1


# Start execution timer
start_time = time.perf_counter()

result = binary_search(arr, target)

# End execution timer
end_time = time.perf_counter()

# Display result
if result != -1:
    print("Element found at index:", result)
else:
    print("Element not found.")

# Execution time
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.9f} seconds")

# Complexity
print("Time Complexity: O(log n)")
print("Space Complexity: O(1)")