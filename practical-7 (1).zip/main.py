import time

# User input
coins = list(map(int, input("Enter coin denominations: ").split()))
amount = int(input("Enter amount: "))

# Sort coins in descending order
coins.sort(reverse=True)

start_time = time.perf_counter()

count = 0
result = []

for coin in coins:
    while amount >= coin:
        amount -= coin
        count += 1
        result.append(coin)

end_time = time.perf_counter()

# Output
if amount == 0:
    print("Coins used:", result)
    print("Minimum number of coins:", count)
else:
    print("Exact coin exchange is not possible.")

execution_time = end_time - start_time
print(f"Execution time: {execution_time:.9f} seconds")

print("Time Complexity: O(C log C + A)")
print("Space Complexity: O(C)")
