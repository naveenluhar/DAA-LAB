import time

# Function for Matrix Chain Multiplication
def matrix_chain_order(p):
    n = len(p) - 1

    # Create DP table
    dp = [[0] * n for _ in range(n)]

    # length is the chain length
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1

            dp[i][j] = float('inf')

            # Try all possible split positions
            for k in range(i, j):
                cost = (
                    dp[i][k]
                    + dp[k + 1][j]
                    + p[i] * p[k + 1] * p[j + 1]
                )

                if cost < dp[i][j]:
                    dp[i][j] = cost

    return dp[0][n - 1]


# Input
n = int(input("Enter number of matrices: "))

print("Enter dimensions of matrices:")

p = []

for i in range(n):
    rows = int(input(f"Enter rows of matrix {i + 1}: "))

    if i == 0:
        p.append(rows)

    columns = int(input(f"Enter columns of matrix {i + 1}: "))
    p.append(columns)


# Start execution time
start_time = time.perf_counter()

# Find minimum multiplication cost
minimum_cost = matrix_chain_order(p)

# End execution time
end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time


# Output
print("\nMinimum number of scalar multiplications =", minimum_cost)

print("Execution Time =", execution_time, "seconds")

print("\nTime Complexity:")
print("Best Case    : O(n^3)")
print("Average Case : O(n^3)")
print("Worst Case   : O(n^3)")

print("\nSpace Complexity: O(n^2)")