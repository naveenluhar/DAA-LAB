import time

# User input
n = int(input("Enter a number: "))

# Start execution timer
start_time = time.perf_counter()

# Iteration
total = 0

for i in range(1, n + 1):
    total += i

# End execution timer
end_time = time.perf_counter()

# Output
print("Sum from 1 to", n, "=", total)

# Execution time
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.9f} seconds")

# Complexity
print("Time Complexity: O(n)")
print("Space Complexity: O(1)")